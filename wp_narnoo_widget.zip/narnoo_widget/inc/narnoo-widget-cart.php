<?php
/**
 * Extract the shortcode data
 */
extract( shortcode_atts( array(
    'confirmation_code'  => '',
), $atts ) );
    
    //Manage the size of the button
    if( empty($confirmation_code) ){
        $confirmation_code = 'true';
    }else{
        $confirmation_code = 'false';
    }
    

   /**
     * Add the script to the footer of the page to increase page load time.
     */
    $script = '<script src="https://d2amq67wh0wnea.cloudfront.net/cart/ota/js/app.js"></script>';
    add_action( 'wp_footer', function() use( $script ){
        echo $script;
    });

    echo '<link href="https://d2amq67wh0wnea.cloudfront.net/cart/ota/css/app.css" rel="stylesheet" />
    <narnoo-cart-widget
    confirmationCode = '.$confirmation_code.'>
    </narnoo-cart-widget>';
?>
