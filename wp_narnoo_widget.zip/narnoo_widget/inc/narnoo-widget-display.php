<?php
/**
 * Extract the shortcode data
 */
extract( shortcode_atts( array(
    'operator_id'           => '',
    'booking_id'            => '',
    'booking_code'          => '',
    'display_extras'        => '',
    'pickup_id'             => '',
    'cart'                  => ''
), $atts ) );

   //We need to get the widget settings from the database
    $option = get_option( 'narnoo_widget_settings' );
    //If the access keys don't exist we have to return false
    if(empty($option['widget_access_key'])){
        $msg = "<div id=\"noo-availability\">";
        $msg .= "<p>No Narnoo API Access key has been provided</p>";
        $msg .= "</div>";
        echo $msg;
        return false;
    }
    //Operator ID
    if(empty($operator_id)){
        $msg = "<div id=\"noo-availability\">";
        $msg .= "<p>No operator id has been provided</p>";
        $msg .= "</div>";
        echo $msg;
        return false;
    }
    //Product ID
    if(empty($booking_id)){
        $msg = "<div id=\"noo-availability\">";
        $msg .= "<p>No booking id has been provided</p>";
        $msg .= "</div>";
        echo $msg;
        return false;
    }
    //Get the access key from the stored local db
    $access_key = $option['widget_access_key'];
    //Get a direct booking code
    if( !empty($booking_code) ){
        $bc = $booking_code;
    }else{
        $bc = null;
    }
    //Cart
    if(empty($cart)){
        if(empty($option['noo_widget_cart_url'])){       
            $msg = "<div id=\"noo-availability\">";
            $msg .= "<p>No uri to a cart page has been found</p>";
            $msg .= "</div>";
            echo $msg;
            return false;
        }else{
            $cart = $option['noo_widget_cart_url'];
        }
    }else{
        $cart = $cart;
    }
    
    //Extras
    if( !empty($display_extras) ){
        $extras = $display_extras;
    }else{
        $extras = 'false';
    }
    //Pickups
    if( !empty($pickup_id) ){
        $pickup = $pickup_id;
    }else{
        $pickup = '';
    }

    
    
    /**
     * Add the script to the footer of the page to increase page load time.
     */
    $script = '<script src="https://d2amq67wh0wnea.cloudfront.net/availability/tours/js/app.js"></script>';
    add_action( 'wp_footer', function() use( $script ){
        echo $script;
    });

    /**
     * Add the CSS to the header of the page.
     * TODO: Make this work!!
    function add_my_stylesheet() 
    {
        wp_register_style(
            'narnoo-availablity-tours-css', // handle name
            'https://d2amq67wh0wnea.cloudfront.net/availability/tours/css/app.css', // the URL of the stylesheet
             false
        );
    
        wp_enqueue_style( 'narnoo-availablity-tours-css' );
    }
    //add_action('wp_enqueue_scripts', 'add_my_stylesheet');
    */

    /**
     * Output the div holder in the correct place
     */
    echo '<link rel="stylesheet" href="https://d2amq67wh0wnea.cloudfront.net/availability/tours/css/app.css">     
    <div id="noo-availability">
        <narnoo-availability-widget
        access_key = "'.$access_key.'"
        operator_id = "'.$operator_id.'"
        booking_id = "'.$booking_id.'"
        checkout_url = "'.$cart.'"
        display_extras = "'.$extras.'"
        pickup_id = "'.$pickup.'"
        booking_code = "'.$bc.'"
        ></narnoo-availability-widget>
    </div>';
?>
