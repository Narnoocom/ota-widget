<?php
/**
 * Extract the shortcode data
 */
extract( shortcode_atts( array(
    'text' => '',
), $atts ) );
    
    if(!empty($text)){
        $t=$text;
    }else{
        $t="Book Now";
    }
    /**
     * Embed script
     */
    $script = "<script>
        function narnooScrollAvailability(n) {
            var el = document.getElementById(n);
            el.scrollIntoView({behavior:'smooth',block:'end',inline:'nearest'});
        }
    </script>";

    /**
     * Add the script to the footer of the page to increase page load time.
     */
    add_action( 'wp_footer', function() use( $script ){
        echo $script;
    });

    echo "<a href=\"javascript:narnooScrollAvailability('noo-availability')\">".$t."</a>";

?>
